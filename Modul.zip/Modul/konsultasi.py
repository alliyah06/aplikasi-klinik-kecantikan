import tkinter as tk
from page_welcome import PageWelcome
from page_login import PageLogin
from page_registration import PageRegistration
from page_skin_type import PageSkinType
from page_face_problem import PageFaceProblem
from page_treatments import PageTreatments
from page_additional_treatments import PageAdditionalTreatments
from page_schedule import PageSchedule
from page_summary import PageSummary
from database import read_schedule_db, write_schedule_db, read_users
from utils import show_confirmation
from tkinter import messagebox
import os  
import json  

class Konsultasi:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Konsultasi Klinik Kecantikan")
        self.root.protocol("WM_DELETE_WINDOW", self.exit_application)
        self.selected_day = None
        self.selected_time = tk.StringVar()
        self.selected_skin_type = tk.StringVar()
        self.selected_face_problem = tk.StringVar()
        self.selected_treatments = []  # To store selected treatments
        self.selected_additional_treatments = []  # To store selected additional treatments
        self.customer_name = ""
        self.registered_customers = {}
        self.load_users()
 
        # Load registered customers
        def load_users(self):
            folder_path = "data"
            file_path = os.path.join(folder_path, "users.json")
            if os.path.exists(file_path):
                with open(file_path, "r") as file:
                    self.registered_customers = json.load(file)
            else:
                self.registered_customers = {}
    

        # Data untuk treatment yang disarankan berdasarkan jenis kulit dan masalah wajah
        self.recommended_treatments = {
            ("kering", "normal"): {
                "Hydrating Facial": 300000,
                "Moisturizing Treatment": 250000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("kering", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Hydrating Facial": 300000
            },
            ("normal", "normal"): {
                "Balancing Facial": 250000,
                "Nourishing Treatment": 300000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("normal", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000
            },
            ("berminyak", "normal"): {
                "Oil Control Facial": 300000,
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("berminyak", "berjerawat"): {
                "Salicylic Acid Treatment": 350000,
                "Gentle Exfoliation": 200000,
                "Oil Control Facial": 300000,
                "Soothing Facial": 350000
            },
            ("kombinasi", "normal"): {
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Nourishing Treatment": 300000,
                "Gentle Exfoliation": 200000
            },
            ("kombinasi", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Mikrodermabrasi": 300000
            },
            ("sensitif", "normal"): {
                "Soothing Facial": 350000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("sensitif", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Soothing Facial": 350000,
                "Salicylic Acid Treatment": 350000
            }
        }

        # Data untuk treatment tambahan
        self.additional_treatments = {
            "Treatment Muka Segar": 150000,
            "Treatment Pembersihan Mendalam": 200000,
            "Treatment Anti Aging": 300000,
            "Treatment Pencerah Kulit": 250000,
            "Treatment Relaksasi Wajah": 200000
        }


        # Halaman
        self.page_welcome = PageWelcome(self.root, self)
        self.page_login = PageLogin(self.root, self)
        self.page_registration = PageRegistration(self.root, self)
        self.page_skin_type = PageSkinType(self.root, self)
        self.page_face_problem = PageFaceProblem(self.root, self)
        self.page_treatments = PageTreatments(self.root, self)
        self.page_additional_treatments = PageAdditionalTreatments(self.root, self)
        self.page_schedule = PageSchedule(self.root, self)
        self.page_summary = PageSummary(self.root, self)

    def page_welcome(self):
        self.page_welcome.show()

    def page_login(self):
        self.page_login.show()

    def page_registration(self):
        self.page_registration.show()

    def page_skin_type(self):
        self.page_skin_type.show()

    def page_face_problem(self):
        self.page_face_problem.show()

    def page_treatments(self):
        self.page_treatments.show()

    def page_additional_treatments(self):
        self.page_additional_treatments.show()

    def page_schedule(self):
        self.page_schedule.show()

    def page_summary(self):
        self.page_summary.show()

    def finish_consultation(self):
        response = show_confirmation("Konsultasi selesai! Terima kasih.\nApakah Anda ingin keluar?")
        if response:
            self.exit_application()
        else:
            self.page_welcome.show()

    def clear_window(self):
        """Membersihkan semua widget di window untuk menampilkan halaman baru"""
        for widget in self.root.winfo_children():
            widget.destroy()

    def exit_application(self):
        """Menampilkan dialog konfirmasi untuk keluar dari aplikasi."""
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin keluar?"):
            self.root.destroy()

    def load_users(self):
        """Muat pengguna terdaftar dari file 'users.json'."""
        folder_path = "data"
        file_path = os.path.join(folder_path, "users.json")
        if os.path.exists(file_path):
            with open(file_path, "r") as file:
                self.registered_customers = json.load(file)
        else:
            self.registered_customers = {}

    def save_users(self):
        """Simpan data pengguna ke file 'users.json'."""
        folder_path = "data"
        if not os.path.exists(folder_path):
            os.makedirs(folder_path, exist_ok=True)  # Buat folder 'data' jika belum ada
        file_path = os.path.join(folder_path, "users.json")

        # Simpan data pengguna ke file tanpa menghapus data yang sudah ada
        with open(file_path, "w") as file:
            json.dump(self.registered_customers, file, indent=4)  # Menyimpan data pengguna ke JSON      
