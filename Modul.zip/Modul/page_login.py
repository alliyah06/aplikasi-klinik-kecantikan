import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class PageLogin:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        # Membersihkan window sebelumnya
        self.konsultasi.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Memuat gambar sebagai background
        bg_image_path = r"assets/bg input login fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Sesuaikan ukuran gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Username input dan label
        canvas.create_text(490, 250, text="Username", font=("Garamond", 15), fill="#990066")
        self.username_entry = tk.Entry(self.root, font=("Arial", 14))
        canvas.create_window(window_width // 1.98, 250, window=self.username_entry)

        # Password input dan label
        canvas.create_text(490, 300, text="Password", font=("Garamond", 15), fill="#990066")
        self.password_entry = tk.Entry(self.root, show="*", font=("Arial", 14))
        canvas.create_window(window_width // 1.98 , 300, window=self.password_entry)

        # Eye button untuk menyembunyikan/menampilkan password
        self.eye_button = tk.Button(self.root, text="👁", command=self.toggle_password, font=("Arial", 12), bd=0)
        canvas.create_window(window_width // 2 + 150, 300, window=self.eye_button)

        # Tombol Login
        login_button = tk.Button(self.root, text="Login", command=self.login_user, bg="#990066", fg="#FFFFFF", width=10, height=1, font=("Arial", 13))
        canvas.create_window(window_width // 1.98, 380, window=login_button)

        # Tombol Kembali
        back_button = tk.Button(self.root, text="Kembali", command=self.konsultasi.page_welcome.show, bg="#990066", fg="#FFFFFF", width=10, height=1, font=("Arial", 13))
        canvas.create_window(window_width // 1.98, 425, window=back_button)

    def toggle_password(self):
        if self.password_entry.cget("show") == "*":
            self.password_entry.config(show="")
            self.eye_button.config(text="🙈")
        else:
            self.password_entry.config(show="*")
            self.eye_button.config(text="👁")

    def login_user(self):
        # Memverifikasi login pengguna
        username = self.username_entry.get()  # Menggunakan atribut kelas
        password = self.password_entry.get()  # Menggunakan atribut kelas

        if not username or not password:
            messagebox.showerror("Error", "Username dan password wajib diisi!")
        elif username not in self.konsultasi.registered_customers:
            messagebox.showerror("Error", "Akun belum terdaftar, silakan registrasi dahulu.")
        elif self.konsultasi.registered_customers[username]["password"] != password:
            messagebox.showerror("Error", "Sandi salah, silakan periksa kembali.")
        else:
            self.konsultasi.customer_name = username
            messagebox.showinfo("Sukses", f"Selamat datang, {self.konsultasi.customer_name}!")
            self.konsultasi.page_skin_type.show()  # Pindah ke halaman jenis kulit
