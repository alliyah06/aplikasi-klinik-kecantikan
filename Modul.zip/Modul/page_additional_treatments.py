import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class PageAdditionalTreatments:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        self.konsultasi.clear_window()
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = "assets/bg add treatment.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height)) 
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")
        
        # Menampilkan Checkbutton untuk treatment tambahan
        y_position = 240  # Posisi awal di canvas
        for treatment, price in self.konsultasi.additional_treatments.items():
            var = tk.BooleanVar()
            treatment_text = f"{treatment} - Rp {price:,}"
            checkbutton = tk.Checkbutton(self.root, text=treatment_text, variable=var, font=("Garamond", 12), bg="#FFFFFF", fg="#000000", anchor="w")
            canvas.create_window(window_width // 2, y_position, window=checkbutton)
            y_position += 40  # Jarak antar checkbutton
            self.konsultasi.selected_additional_treatments.append((treatment, var, price))

        # Tombol "Selanjutnya"
        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=self.konsultasi.page_schedule.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + 50, window=next_button)

        # Tombol "Kembali"
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.konsultasi.page_treatments.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + 100, window=back_button)
