import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import json

class PageRegistration:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        """Menampilkan halaman registrasi dan memuat elemen-elemen UI"""
        self.konsultasi.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Memuat gambar sebagai background
        bg_image_path = r"assets/bg input username pw fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Username input
        canvas.create_text(490, 250, text="Username", font=("Garamond", 15), fill="#990066")
        self.name_entry = tk.Entry(self.root, font=("Arial", 14))
        canvas.create_window(650, 250, window=self.name_entry)

        # Password input
        canvas.create_text(490, 300, text="Password", font=("Garamond", 15), fill="#990066")
        self.password_entry = tk.Entry(self.root, font=("Arial", 14), show="*")
        canvas.create_window(650, 300, window=self.password_entry)

        # Eye button untuk menyembunyikan/menampilkan password
        self.eye_button = tk.Button(self.root, text="👁", command=self.toggle_password, font=("Arial", 12), bd=0)
        canvas.create_window(785, 300, window=self.eye_button)

        # Tombol Registrasi
        register_button = tk.Button(self.root, text="Registrasi", font=("Arial", 13), command=self.register, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 1.97, 380, window=register_button)

        # Tombol Kembali
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.konsultasi.page_welcome.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 1.97, 425, window=back_button)

    def toggle_password(self):
        """Menangani perintah untuk menyembunyikan atau menampilkan password"""
        if self.password_entry.cget("show") == "*":
            self.password_entry.config(show="")
            self.eye_button.config(text="🙈")
        else:
            self.password_entry.config(show="*")
            self.eye_button.config(text="👁")

    def load_users(self):
        """Memuat data pengguna dari file 'users.json'"""
        folder_path = "data"
        file_path = os.path.join(folder_path, "users.json")
        if os.path.exists(file_path):
            with open(file_path, "r") as file:
                self.konsultasi.registered_customers = json.load(file)
        else:
            self.konsultasi.registered_customers = {}

    def register(self):
        """Menangani proses registrasi pengguna"""
        username = self.name_entry.get()  # Gantilah 'self.username_entry' menjadi 'self.name_entry'
        password = self.password_entry.get()

        # Validasi input
        if username and password:
            if username in self.konsultasi.registered_customers:
                messagebox.showerror("Error", "Username sudah terdaftar!")
            else:
                # Tambahkan data pengguna baru ke dictionary registered_customers
                self.konsultasi.registered_customers[username] = {"password": password}
                
                # Simpan perubahan ke file users.json
                self.konsultasi.save_users()  # Memanggil save_users() untuk menyimpan data
                
                messagebox.showinfo("Registrasi Berhasil", "Registrasi berhasil, silakan login.")
                self.konsultasi.page_login.show()  # Pindah ke halaman login setelah registrasi berhasil
        else:
            messagebox.showerror("Error", "Username dan password tidak boleh kosong")

    

