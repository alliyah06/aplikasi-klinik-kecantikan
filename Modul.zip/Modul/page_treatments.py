import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class PageTreatments:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        self.konsultasi.clear_window()
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        bg_image_path = "assets/bg perawatan wajah fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Mendapatkan perawatan yang direkomendasikan
        skin_type = self.konsultasi.selected_skin_type.get().lower()
        face_problem = self.konsultasi.selected_face_problem.get().lower()
        available_treatments = self.konsultasi.recommended_treatments.get((skin_type, face_problem), {})

        y_position = 240
        self.konsultasi.selected_treatments.clear()  # Menghindari data duplikat

        for index, (treatment, price) in enumerate(available_treatments.items()):
            var = tk.BooleanVar()
            treatment_text = f"{treatment} - Rp {price:,}"
            checkbutton = tk.Checkbutton(self.root, text=treatment_text, variable=var, font=("Garamond", 12), fg="#000000", anchor="w", bg="#FFFFFF")
            canvas.create_window(window_width // 2, y_position + (index * 40), window=checkbutton)
            self.konsultasi.selected_treatments.append((treatment, var, price))

        def handle_treatments_selection():
            if not any(t[1].get() for t in self.konsultasi.selected_treatments):
                messagebox.showerror("Error", "Pilih perawatan terlebih dahulu!")
            else:
                self.konsultasi.page_additional_treatments.show()

        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_treatments_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + len(self.konsultasi.selected_treatments) * 40 + 50, window=next_button)

        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.konsultasi.page_face_problem.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + len(self.konsultasi.selected_treatments) * 40 + 100, window=back_button)
