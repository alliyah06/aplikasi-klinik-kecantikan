import tkinter as tk
from konsultasi import Konsultasi

if __name__ == "__main__":
    root = tk.Tk()
    app = Konsultasi(root)  # Membuat instance dari kelas Konsultasi
    app.page_welcome.show()  # Memanggil fungsi show() untuk menampilkan halaman selamat datang
    root.mainloop()  # Memulai loop utama tkinter
