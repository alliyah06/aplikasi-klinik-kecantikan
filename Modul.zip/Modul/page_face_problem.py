import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

class PageFaceProblem:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        self.konsultasi.clear_window()
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        bg_image_path = "assets/bg face problem fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menambahkan combobox untuk memilih masalah wajah
        face_problems = ["Normal", "Berjerawat"]
        combobox = ttk.Combobox(self.root, textvariable=self.konsultasi.selected_face_problem, values=face_problems, state="readonly", font=("Arial", 12))
        canvas.create_window(window_width // 2, 275, window=combobox)

        def handle_face_problem_selection():
            if not self.konsultasi.selected_face_problem.get():
                messagebox.showerror("Error", "Pilih masalah wajah terlebih dahulu!")
            else:
                self.konsultasi.page_treatments.show()

        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_face_problem_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 350, window=next_button)

        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.konsultasi.page_skin_type.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 400, window=back_button)
