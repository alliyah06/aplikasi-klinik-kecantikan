import json

def read_schedule_db():
    """Membaca data jadwal dari file schedule_db.json."""
    try:
        with open('schedule_db.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def write_schedule_db(schedule_db):
    """Menulis data jadwal ke file schedule_db.json."""
    with open('schedule_db.json', 'w') as f:
        json.dump(schedule_db, f, indent=4)

def read_users():
    """Membaca data pengguna dari file users.json."""
    try:
        with open('data/users.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def write_users(users):
    """Menulis data pengguna ke file users.json."""
    with open('data/users.json', 'w') as f:
        json.dump(users, f, indent=4)
