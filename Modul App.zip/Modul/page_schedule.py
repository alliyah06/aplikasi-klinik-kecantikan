import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import Calendar
from PIL import Image, ImageTk
import datetime
from database import read_schedule_db, write_schedule_db

class PageSchedule:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg jadwal fix.png"
        bg_image = Image.open(bg_image_path).resize((window_width, window_height))
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas untuk background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Pilihan Hari menggunakan kalender
        calendar = Calendar(self.root, selectmode="day", date_pattern="yyyy-MM-dd")
        canvas.create_window(window_width // 3.68, 350, window=calendar)

        # Pilihan Waktu
        self.selected_time = tk.StringVar()
        time_combobox = ttk.Combobox(self.root, textvariable=self.selected_time, state="readonly")
        canvas.create_window(window_width // 1.35, 300, window=time_combobox)

        def update_times(event):
            selected_day = calendar.get_date()
            if selected_day:
                # Menampilkan pesan konfirmasi tanggal
                date_obj = datetime.datetime.strptime(selected_day, "%Y-%m-%d")
                day_name = date_obj.strftime("%A")  # Nama hari, misalnya "Jumat"
                formatted_date = date_obj.strftime("%d %B %Y")  # Format tanggal, misalnya "06 Desember 2024"
                confirmation_message = f"Apakah Anda yakin memilih {day_name}, {formatted_date}?"
                
                # Menampilkan pesan konfirmasi
                confirmation = messagebox.askyesno("Konfirmasi Tanggal", confirmation_message)
                
                if confirmation:
                    # Jika ya, tampilkan pilihan waktu
                    schedule_db = read_schedule_db()
                    unavailable_times = schedule_db.get(selected_day, [])
                    all_times = ["10:00", "14:00", "17:00", "20:00"]  # Contoh waktu
                    available_times = [time for time in all_times if time not in unavailable_times]
                    time_combobox["values"] = available_times
                    self.selected_time.set("")
                else:
                    # Jika tidak, reset kalender dan combobox waktu
                    calendar.selection_clear()
                    time_combobox.set("")

        calendar.bind("<<CalendarSelected>>", update_times)

        # Tombol "Selanjutnya"
        def handle_schedule_selection():
            selected_day = calendar.get_date()
            selected_time = self.selected_time.get()

            if not selected_day:
                messagebox.showerror("Error", "Pilih hari terlebih dahulu!")
                return
            if not selected_time:
                messagebox.showerror("Error", "Pilih jam terlebih dahulu!")
                return

            schedule_db = read_schedule_db()
            if selected_day in schedule_db and selected_time in schedule_db[selected_day]:
                messagebox.showerror("Jadwal Sudah Terisi", f"Jadwal sudah penuh pada {selected_day} pukul {selected_time}.")
                return

            # Simpan jadwal
            if selected_day not in schedule_db:
                schedule_db[selected_day] = []
            schedule_db[selected_day].append(selected_time)
            write_schedule_db(schedule_db)

            # Simpan jadwal terpilih
            self.konsultasi.selected_day = selected_day
            self.konsultasi.selected_time.set(selected_time)

            self.konsultasi.page_summary.show()

        next_button = tk.Button(self.root, text="Selanjutnya", command=handle_schedule_selection, bg="#990066", fg="white")
        canvas.create_window(window_width // 2, 500, window=next_button)

        # Tombol "Kembali"
        back_button = tk.Button(self.root, text="Kembali", command=self.konsultasi.page_additional_treatments.show, bg="#990066", fg="white")
        canvas.create_window(window_width // 2, 550, window=back_button)
