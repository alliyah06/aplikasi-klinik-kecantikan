import datetime
from tkinter import messagebox

def format_date(date_str):
    """Mengonversi string tanggal ke format yang lebih mudah dibaca."""
    date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d")
    return date_obj.strftime("%A, %d %B %Y")

def show_confirmation(message):
    """Menampilkan dialog konfirmasi Yes/No."""
    return messagebox.askyesno("Konfirmasi", message)
