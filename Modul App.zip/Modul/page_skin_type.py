import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

class PageSkinType:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg jenis kulit fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menambahkan combobox untuk memilih jenis kulit
        skin_types = ["Kering", "Normal", "Berminyak", "Kombinasi", "Sensitif", "Tidak Diketahui"]
        combobox = ttk.Combobox(self.root, textvariable=self.konsultasi.selected_skin_type, values=skin_types, state="readonly", font=("Arial", 12))
        canvas.create_window(window_width // 2, 275, window=combobox)

        def handle_skin_type_selection():
            if self.konsultasi.selected_skin_type.get() == "Tidak Diketahui":
                result = messagebox.showinfo("Informasi", "Silakan konsultasi untuk jenis kulit Anda terlebih dahulu kepada dokter.")
                if result:
                    self.konsultasi.page_schedule.show()
            elif not self.konsultasi.selected_skin_type.get():
                messagebox.showerror("Error", "Pilih jenis kulit terlebih dahulu!")
            else:
                self.konsultasi.page_face_problem.show()

        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_skin_type_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 350, window=next_button)

        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.konsultasi.page_login.show, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 400, window=back_button)
