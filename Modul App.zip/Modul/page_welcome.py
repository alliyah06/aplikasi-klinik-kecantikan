import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class PageWelcome:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi  # Menghubungkan ke kelas Konsultasi

    def show(self):
        # Membersihkan window sebelumnya
        self.konsultasi.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Memuat gambar sebagai background (ukuran seperti ppt)
        bg_image = Image.open(r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg welcome page fix.png") 
        bg_image = bg_image.resize((1280, 720))  
        self.bg_photo = ImageTk.PhotoImage(bg_image) 

        # Membuat canvas dan menampilkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=1280, height=720)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Membuat tombol login dan registrasi
        login_button = tk.Button(self.root, text="Login", font=("Arial", 15), command=self.konsultasi.page_login.show, bg="#990066", fg="#FFFFFF", width=12, height=1)
        reg_button = tk.Button(self.root, text="Registrasi", font=("Arial", 15), command=self.konsultasi.page_registration.show, bg="#990066", fg="#FFFFFF", width=15, height=1)

        # Menempatkan tombol di atas canvas
        canvas.create_window(625, 325, window=login_button)
        canvas.create_window(625, 400, window=reg_button)
