class Data:
 
    RECOMMENDED_TREATMENTS = {
            ("kering", "normal"): {
                "Hydrating Facial": 300000,
                "Moisturizing Treatment": 250000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("kering", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Hydrating Facial": 300000
            },
            ("normal", "normal"): {
                "Balancing Facial": 250000,
                "Nourishing Treatment": 300000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("normal", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000
            },
            ("berminyak", "normal"): {
                "Oil Control Facial": 300000,
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("berminyak", "berjerawat"): {
                "Salicylic Acid Treatment": 350000,
                "Gentle Exfoliation": 200000,
                "Oil Control Facial": 300000,
                "Soothing Facial": 350000
            },
            ("kombinasi", "normal"): {
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Nourishing Treatment": 300000,
                "Gentle Exfoliation": 200000
            },
            ("kombinasi", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Mikrodermabrasi": 300000
            },
            ("sensitif", "normal"): {
                "Soothing Facial": 350000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("sensitif", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Soothing Facial": 350000,
                "Salicylic Acid Treatment": 350000
            }
        }

    ADDITIONAL_TREATMENTS = {
        "Treatment Muka Segar": 150000,
        "Treatment Pembersihan Mendalam": 200000,
        "Treatment Anti Aging": 300000,
        "Treatment Pencerah Kulit": 250000,
        "Treatment Relaksasi Wajah": 200000,
    }
