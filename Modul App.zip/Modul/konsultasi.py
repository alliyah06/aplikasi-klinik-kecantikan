import tkinter as tk
from tkinter import ttk, messagebox
from page_welcome import PageWelcome
from page_login import PageLogin
from page_registration import PageRegistration
from page_skin_type import PageSkinType
from page_face_problem import PageFaceProblem
from page_treatments import PageTreatments
from page_additional_treatments import PageAdditionalTreatments
from page_schedule import PageSchedule
from page_summary import PageSummary
from database import read_schedule_db, write_schedule_db
from utils import show_confirmation

class Konsultasi:
    def __init__(self, root):
        self.root = root
        self.selected_treatments = []
        self.selected_additional_treatments = []
        self.selected_skin_type = tk.StringVar()
        self.selected_face_problem = tk.StringVar()
        self.selected_day = None
        self.selected_time = tk.StringVar()

        # Halaman
        self.page_welcome = PageWelcome(self.root, self)
        self.page_login = PageLogin(self.root, self)
        self.page_registration = PageRegistration(self.root, self)
        self.page_skin_type = PageSkinType(self.root, self)
        self.page_face_problem = PageFaceProblem(self.root, self)
        self.page_treatments = PageTreatments(self.root, self)
        self.page_additional_treatments = PageAdditionalTreatments(self.root, self)
        self.page_schedule = PageSchedule(self.root, self)
        self.page_summary = PageSummary(self.root, self)

    def page_welcome(self):
        self.page_welcome.show()

    def page_login(self):
        self.page_login.show()

    def page_registration(self):
        self.page_registration.show()

    def page_skin_type(self):
        self.page_skin_type.show()

    def page_face_problem(self):
        self.page_face_problem.show()

    def page_treatments(self):
        self.page_treatments.show()

    def page_additional_treatments(self):
        self.page_additional_treatments.show()

    def page_schedule(self):
        self.page_schedule.show()

    def page_summary(self):
        self.page_summary.show()

    def finish_consultation(self):
        response = show_confirmation("Konsultasi selesai! Terima kasih.\nApakah Anda ingin keluar?")
        if response:
            self.exit_application()
        else:
            self.page_welcome.show()

    def clear_window(self):
        """Membersihkan semua widget di window untuk menampilkan halaman baru"""
        for widget in self.root.winfo_children():
            widget.destroy()

    def exit_application(self):
        """Menampilkan dialog konfirmasi untuk keluar dari aplikasi."""
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin keluar?"):
            self.root.destroy()
