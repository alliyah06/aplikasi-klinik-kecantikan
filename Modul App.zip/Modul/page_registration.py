import tkinter as tk
from tkinter import messagebox
import json
import os
from PIL import Image, ImageTk

class PageRegistration:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi
        
              # Load registered customers
        try:
            with open("users.json", "r") as file:
                self.registered_customers = json.load(file)
        except FileNotFoundError:
            self.registered_customers = {}

    def show(self):
        self.konsultasi.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg input username pw fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)

        # Form registrasi
        canvas.create_text(window_width // 2, 200, text="Registrasi", font=("Arial", 20, "bold"))

        username_label = tk.Label(self.root, text="Username", font=("Arial", 14))
        canvas.create_window(window_width // 2, 250, window=username_label)

        self.username_entry = tk.Entry(self.root, font=("Arial", 14))
        canvas.create_window(window_width // 2, 280, window=self.username_entry)

        password_label = tk.Label(self.root, text="Password", font=("Arial", 14))
        canvas.create_window(window_width // 2, 320, window=password_label)

        self.password_entry = tk.Entry(self.root, show="*", font=("Arial", 14))
        canvas.create_window(window_width // 2, 350, window=self.password_entry)

        # Tombol Registrasi
        register_button = tk.Button(self.root, text="Registrasi", command=self.register, bg="#990066", fg="#FFFFFF", width=15, height=2)
        canvas.create_window(window_width // 2, 400, window=register_button)
        back_button = tk.Button(self.root, text="Kembali", command=self.page_welcome, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 1.98, 450, window=back_button)
        
    def toggle_password(self):
        if self.password_entry.cget("show") == "*":
            self.password_entry.config(show="")
            self.eye_button.config(text="🙈")
        else:
            self.password_entry.config(show="*")
            self.eye_button.config(text="👁")


    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Validasi input
        if username and password:
            if username in self.konsultasi.registered_customers:
                messagebox.showerror("Error", "Username sudah terdaftar!")
            else:
                self.konsultasi.registered_customers[username] = {"password": password}
                # Menyimpan data pengguna ke file users.json
                folder_path = "data"
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path, exist_ok=True)
                file_path = os.path.join(folder_path, "users.json")
                with open(file_path, "w") as file:
                    json.dump(self.konsultasi.registered_customers, file, indent=4)
                messagebox.showinfo("Registrasi Berhasil", "Registrasi berhasil, silahkan login")
                self.konsultasi.page_login.show()  # Arahkan ke halaman login
        else:
            messagebox.showerror("Error", "Username dan password tidak boleh kosong")
