import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class PageLogin:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        # Membersihkan window sebelumnya
        self.konsultasi.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Memuat gambar sebagai background
        bg_image_path = r"assets/bg input login fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Sesuaikan ukuran gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Form untuk username dan password
        canvas.create_text(window_width // 2, 200, text="Login", font=("Arial", 20, "bold"))

        # Username input
        username_label = tk.Label(self.root, text="Username", font=("Arial", 14))
        canvas.create_window(window_width // 2, 250, window=username_label)

        self.username_entry = tk.Entry(self.root, font=("Arial", 14))
        canvas.create_window(window_width // 2, 280, window=self.username_entry)

        # Password input
        password_label = tk.Label(self.root, text="Password", font=("Arial", 14))
        canvas.create_window(window_width // 2, 320, window=password_label)

        self.password_entry = tk.Entry(self.root, show="*", font=("Arial", 14))
        canvas.create_window(window_width // 2, 350, window=self.password_entry)
        
        # Eye button untuk menyembunyikan/menampilkan password
        self.eye_button = tk.Button(self.root, text="👁", command=self.toggle_password, font=("Arial", 12), bd=0)
        canvas.create_window(780, 300, window=self.eye_button)


        # Tombol Login
        login_button = tk.Button(self.root, text="Login", command=self.login_user, bg="#990066", fg="#FFFFFF", width=15, height=1)
        canvas.create_window(window_width // 2, 400, window=login_button)
        back_button = tk.Button(self.root, text="Kembali", command=self.page_welcome, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 1.98, 450, window=back_button)
        
    def login_user(self):
        """Memverifikasi login pengguna"""
        # Ambil input dari Entry
        name = self.name_entry.get()
        password = self.password_entry.get()

        if not name or not password:
            messagebox.showerror("Error", "Username dan password wajib diisi!")
        elif name not in self.registered_customers:
            messagebox.showerror("Error", "Akun belum terdaftar, silakan registrasi dahulu.")
        elif self.registered_customers[name]["password"] != password:
            messagebox.showerror("Error", "Sandi salah, silakan periksa kembali.")
        else:
            self.customer_name = name
            messagebox.showinfo("Sukses", f"Selamat datang, {self.customer_name}!")
            self.page_skin_type()
