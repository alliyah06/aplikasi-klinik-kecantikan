import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import datetime

class PageSummary:
    def __init__(self, root, konsultasi):
        self.root = root
        self.konsultasi = konsultasi

    def show(self):
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg nota fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menghitung total harga
        total_treatment_price = sum([t[2] for t in self.konsultasi.selected_treatments if t[1].get()])
        total_additional_price = sum([t[2] for t in self.konsultasi.selected_additional_treatments if t[1].get()])
        total_price = total_treatment_price + total_additional_price
        if self.konsultasi.selected_skin_type.get() == "Tidak Diketahui":
            total_price += 100000  # Biaya konsultasi

        # Menentukan nama hari dan tanggal yang dipilih
        if self.konsultasi.selected_day:
            date_obj = datetime.datetime.strptime(self.konsultasi.selected_day, "%Y-%m-%d")
            day_name = date_obj.strftime("%A")
            formatted_date = date_obj.strftime("%d %B %Y")
        else:
            day_name = '-'
            formatted_date = '-'

        # Menampilkan summary text
        summary_text = f"""
    Nama: {self.konsultasi.customer_name if self.konsultasi.customer_name else '-' }
    Jenis Kulit: {self.konsultasi.selected_skin_type.get() if self.konsultasi.selected_skin_type.get() else '-'}
    Masalah Wajah: {self.konsultasi.selected_face_problem.get() if self.konsultasi.selected_face_problem.get() else '-'}
    Treatment: {', '.join([t[0] for t in self.konsultasi.selected_treatments if t[1].get()]) if any(t[1].get() for t in self.konsultasi.selected_treatments) else '-'}
    Treatment Tambahan: {', '.join([t[0] for t in self.konsultasi.selected_additional_treatments if t[1].get()]) if any(t[1].get() for t in self.konsultasi.selected_additional_treatments) else '-'}
    Jadwal Treatment: {day_name}, {formatted_date}, Pukul {self.konsultasi.selected_time.get() if self.konsultasi.selected_time.get() else '-'}
    Total Harga: Rp {total_price:,}
        """

        canvas.create_text(window_width // 2, 300, text=summary_text.strip(), fill="black", font=("Arial", 14), justify="center")

        # Tombol "Selesai"
        finish_button = tk.Button(self.root, text="Selesai", font=("Arial", 13), command=self.konsultasi.finish_consultation, bg="#990066", fg="#FFFFFF", width=15, height=1)
        canvas.create_window(window_width // 2, 500, window=finish_button)
        
    def exit_application(self):
        """Menampilkan dialog konfirmasi untuk keluar dari aplikasi."""
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin keluar?"):
            self.root.destroy()
