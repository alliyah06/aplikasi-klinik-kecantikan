import os
import json
from tkinter import ttk, messagebox
import tkinter as tk
from PIL import Image, ImageTk

class LoginModule:
    
    def __init__(self, root, on_success_callback):
        self.root = root
        self.on_success_callback = on_success_callback  # Callback setelah login berhasil
        self.registered_customers = {}
        self.load_users()
        
        
    def page_registration(self):
        self.clear_window()

        # Ukuran window 1280x720
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg input username pw fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Username input
        canvas.create_text(500, 250, text="Username", font=("Garamond", 15), fill="#990066")
        self.name_entry = tk.Entry(self.root, font=("Arial", 12))
        canvas.create_window(650, 250, window=self.name_entry)

        # Password input
        canvas.create_text(500, 300, text="Password", font=("Garamond", 15), fill="#990066")
        self.password_entry = tk.Entry(self.root, font=("Arial", 12), show="*")
        canvas.create_window(650, 300, window=self.password_entry)

        # Eye button untuk menyembunyikan/menampilkan password
        self.eye_button = tk.Button(self.root, text="👁", command=self.toggle_password, font=("Arial", 12), bd=0)
        canvas.create_window(780, 300, window=self.eye_button)

        # Menambahkan tombol Registrasi dan Kembali
        register_button = tk.Button(self.root, text="Registrasi", font=("Arial", 13), command=self.register_user, bg="#990066", fg="#FFFFFF", width=10, height=1)
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_welcome, bg="#990066", fg="#FFFFFF", width=10, height=1)

        # Menempatkan tombol di atas canvas
        canvas.create_window(window_width // 1.98, 380, window=register_button)
        canvas.create_window(window_width // 1.98, 450, window=back_button)

    def toggle_password(self):
        if self.password_entry.cget("show") == "*":
            self.password_entry.config(show="")
            self.eye_button.config(text="🙈")
        else:
            self.password_entry.config(show="*")
            self.eye_button.config(text="👁")

    def register_user(self):
        username = self.name_entry.get()
        password = self.password_entry.get()

        if username and password:
            if username in self.registered_customers:
                messagebox.showerror("Error", "Username sudah terdaftar!")
            else:
                self.registered_customers[username] = {"password": password}
                # Menyimpan data pengguna ke file users.json
                folder_path = "data"
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path, exist_ok=True)
                file_path = os.path.join(folder_path, "users.json")
                
                try:
                    with open(file_path, "w") as file:
                        json.dump(self.registered_customers, file, indent=4)
                    messagebox.showinfo("Registrasi Berhasil", "Registrasi berhasil, silahkan login")
                    self.page_login()
                except Exception as e:
                    messagebox.showerror("Error", f"Gagal menyimpan data: {str(e)}")
        else:
            messagebox.showerror("Error", "Username dan password tidak boleh kosong")


    def load_users(self):
        folder_path = "data"
        file_path = os.path.join(folder_path, "users.json")
        if os.path.exists(file_path):
            with open(file_path, "r") as file:
                self.registered_customers = json.load(file)
        else:
            self.registered_customers = {}

 
    def page_login(self):
        self.clear_window()

        # Ukuran window 1280x720
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg input login fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Username input
        canvas.create_text(500, 250, text="Username", font=("Garamond", 15), fill="#990066")
        self.name_entry = tk.Entry(self.root, font=("Arial", 12))
        canvas.create_window(650, 250, window=self.name_entry)

        # Password input
        canvas.create_text(500, 300, text="Password", font=("Garamond", 15), fill="#990066")
        self.password_entry = tk.Entry(self.root, font=("Arial", 12), show="*")
        canvas.create_window(650, 300, window=self.password_entry)

        # Eye button untuk menyembunyikan/menampilkan password
        self.eye_button = tk.Button(self.root, text="👁", command=self.toggle_password, font=("Arial", 12), bd=0)
        canvas.create_window(780, 300, window=self.eye_button)

        # Menambahkan tombol Login dan Kembali
        login_button = tk.Button(self.root, text="Login", font=("Arial", 13), command=self.login_user, bg="#990066", fg="#FFFFFF", width=10, height=1)
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_welcome, bg="#990066", fg="#FFFFFF", width=10, height=1)

        # Menempatkan tombol di atas canvas
        canvas.create_window(window_width // 1.98, 380, window=login_button)
        canvas.create_window(window_width // 1.98, 450, window=back_button)
        
    def login_user(self):
        """Memverifikasi login pengguna"""
        # Ambil input dari Entry
        name = self.name_entry.get()
        password = self.password_entry.get()

        if not name or not password:
            messagebox.showerror("Error", "Username dan password wajib diisi!")
        elif name not in self.registered_customers:
            messagebox.showerror("Error", "Akun belum terdaftar, silakan registrasi dahulu.")
        elif self.registered_customers[name]["password"] != password:
            messagebox.showerror("Error", "Sandi salah, silakan periksa kembali.")
        else:
            self.customer_name = name
            messagebox.showinfo("Sukses", f"Selamat datang, {self.customer_name}!")
            self.page_skin_type()
    
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()