import tkinter as tk
import os
import json
from tkinter import messagebox
from PIL import Image, ImageTk
import datetime

class Summary:
    def __init__(self, root, customer_name, selected_skin_type, selected_face_problem, selected_treatments, selected_additional_treatments, selected_day, selected_time):
        self.root = root
        self.customer_name = customer_name
        self.selected_skin_type = selected_skin_type
        self.selected_face_problem = selected_face_problem
        self.selected_treatments = selected_treatments
        self.selected_additional_treatments = selected_additional_treatments
        self.selected_day = selected_day
        self.selected_time = selected_time
        self.page_summary()

    def clear_window(self):
        """Menghapus semua widget di dalam window."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def exit_application(self):
        """Menampilkan dialog konfirmasi untuk keluar dari aplikasi."""
        if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin keluar?"):
            self.root.destroy()

    def page_summary(self):
        self.clear_window()

        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg nota fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menghitung total harga
        total_treatment_price = sum([t[2] for t in self.selected_treatments if t[1].get()])
        total_additional_price = sum([t[2] for t in self.selected_additional_treatments if t[1].get()])
        total_price = total_treatment_price + total_additional_price
        if self.selected_skin_type.get() == "Tidak Diketahui":
            total_price += 100000  # Biaya konsultasi

        # Menentukan nama hari dan tanggal yang dipilih
        if self.selected_day:
            date_obj = datetime.datetime.strptime(self.selected_day, "%Y-%m-%d")
            day_name = date_obj.strftime("%A")
            formatted_date = date_obj.strftime("%d %B %Y")
        else:
            day_name = '-'
            formatted_date = '-'

        # Menampilkan summary text
        summary_text = f"""
    Nama: {self.customer_name if self.customer_name else '-'}
    Jenis Kulit: {self.selected_skin_type.get() if self.selected_skin_type.get() else '-'}
    Masalah Wajah: {self.selected_face_problem.get() if self.selected_face_problem.get() else '-'}
    Treatment: {', '.join([t[0] for t in self.selected_treatments if t[1].get()]) if any(t[1].get() for t in self.selected_treatments) else '-'}
    Treatment Tambahan: {', '.join([t[0] for t in self.selected_additional_treatments if t[1].get()]) if any(t[1].get() for t in self.selected_additional_treatments) else '-'}
    Jadwal Treatment: {day_name}, {formatted_date}, Pukul {self.selected_time.get() if self.selected_time.get() else '-'}
    Total Harga: Rp {total_price:,}
        """

        canvas.create_text(window_width // 2, 300, text=summary_text.strip(), fill="black", font=("Arial", 14), justify="center")

        # Tombol "Selesai"
        finish_button = tk.Button(self.root, text="Selesai", font=("Arial", 13), command=self.finish_consultation, bg="#990066", fg="#FFFFFF", width=15, height=1)
        canvas.create_window(window_width // 2, 500, window=finish_button)

    def finish_consultation(self):
        """Menampilkan pesan selesai dengan opsi Yes/No."""
        response = messagebox.askyesno("Selesai", "Konsultasi selesai! Terima kasih.\nApakah Anda ingin keluar?")
        if response:  # Jika memilih Yes
            self.exit_application()  # Keluar dari aplikasi
        else:  # Jika memilih No
            self.page_welcome()  # Kembali ke halaman utama
