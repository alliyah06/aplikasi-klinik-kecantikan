import tkinter as tk
from PIL import Image, ImageTk
from login import LoginModule
from treatment import TreatmentModule
from schedule import ScheduleModule
from nota import NotaModule


class MainApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Klinik Kecantikan")
        self.current_user = None
        self.page_welcome()
        self.root.title("Aplikasi Konsultasi Klinik Kecantikan")
        self.root.protocol("WM_DELETE_WINDOW", self.exit_application)
        
    def page_welcome(self):
        self.clear_window()

        # Memuat gambar sebagai background (ukuran seperti ppt)
        bg_image = Image.open(r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg welcome page fix.png") 
        bg_image = bg_image.resize((1280, 720))  
        self.bg_photo = ImageTk.PhotoImage(bg_image)  
        # Membuat canvas dan menampilkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=1280, height=720)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Membuat tombol login dan registrasi
        login_button = tk.Button(self.root, text="Login", font=("Arial", 15), command=self.page_login, bg="#990066", fg="#FFFFFF", width=12, height=1)
        reg_button = tk.Button(self.root, text="Registrasi", font=("Arial", 15), command=self.page_registration, bg="#990066", fg="#FFFFFF", width=15, height=1)

        # Menempatkan tombol di atas canvas
        canvas.create_window(625, 325, window=login_button)
        canvas.create_window(625, 400, window=reg_button)
        
    def page_login(self):
        """Halaman Login"""
        self.clear_window()

        login_module = LoginModule(self.root, self.on_login_success)
        login_module.page_login()

    def on_login_success(self, username):
        """Callback setelah login sukses"""
        self.current_user = username
        self.page_treatment()

    def page_treatment(self):
        """Halaman Treatment"""
        self.clear_window()
        treatment_module = TreatmentModule(self.root)
        treatment_module.page_treatment()

    def page_schedule(self):
        """Halaman Jadwal Dokter"""
        self.clear_window()
        schedule_module = ScheduleModule(self.root)
        schedule_module.page_schedule()
    
    def page_nota(self):
         """Halaman Nota konsultasi"""
         self.clear_window()
         nota_module = NotaModule(self.root)
         nota_module.page_nota()
         
    def clear_window(self):
        """Membersihkan semua widget pada window"""
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()
