import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

class Konsultasi:
    def __init__(self, root):
        self.root = root
        self.selected_skin_type = tk.StringVar()
        self.selected_face_problem = tk.StringVar()
        self.selected_treatments = []
        self.selected_additional_treatments = []
        
        
        recommended_treatments ={
            ("kering", "normal"): {
                "Hydrating Facial": 300000,
                "Moisturizing Treatment": 250000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("kering", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Hydrating Facial": 300000
            },
            ("normal", "normal"): {
                "Balancing Facial": 250000,
                "Nourishing Treatment": 300000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("normal", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Gentle Exfoliation": 200000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000
            },
            ("berminyak", "normal"): {
                "Oil Control Facial": 300000,
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Vitamin C Infusion": 400000
            },
            ("berminyak", "berjerawat"): {
                "Salicylic Acid Treatment": 350000,
                "Gentle Exfoliation": 200000,
                "Oil Control Facial": 300000,
                "Soothing Facial": 350000
            },
            ("kombinasi", "normal"): {
                "Balancing Facial": 250000,
                "Hydrating Facial": 300000,
                "Nourishing Treatment": 300000,
                "Gentle Exfoliation": 200000
            },
            ("kombinasi", "berjerawat"): {
                "Oil Control Facial": 300000,
                "Salicylic Acid Treatment": 350000,
                "Soothing Facial": 350000,
                "Mikrodermabrasi": 300000
            },
            ("sensitif", "normal"): {
                "Soothing Facial": 350000,
                "Gentle Hydration": 400000,
                "Nourishing Treatment": 300000,
                "Vitamin C Infusion": 400000
            },
            ("sensitif", "berjerawat"): {
                "Gentle Exfoliation": 200000,
                "Soothing Facial": 350000,
                "Salicylic Acid Treatment": 350000
            }
        }

        additional_treatments ={
            "Treatment Muka Segar": 150000,
            "Treatment Pembersihan Mendalam": 200000,
            "Treatment Anti Aging": 300000,
            "Treatment Pencerah Kulit": 250000,
            "Treatment Relaksasi Wajah": 200000
        }


       # Data perawatan sudah didefinisikan, tidak perlu memanggil 'treatments'
        self.recommended_treatments = recommended_treatments
        self.additional_treatments = additional_treatments


        self.page_skin_type()

    def page_skin_type(self):
        self.clear_window()

        # Ukuran window 1280x720
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg jenis kulit fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menambahkan combobox untuk memilih jenis kulit
        skin_types = ["Kering", "Normal", "Berminyak", "Kombinasi", "Sensitif", "Tidak Diketahui"]
        combobox = ttk.Combobox(self.root, textvariable=self.selected_skin_type, values=skin_types, state="readonly", font=("Arial", 12))
        canvas.create_window(window_width // 2, 275, window=combobox)

        def handle_skin_type_selection():
            if self.selected_skin_type.get() == "Tidak Diketahui":
                result = messagebox.showinfo("Informasi", "Silakan konsultasi untuk jenis kulit Anda terlebih dahulu kepada dokter.")
                if result:
                    self.page_schedule()
            elif not self.selected_skin_type.get():
                messagebox.showerror("Error", "Pilih jenis kulit terlebih dahulu!")
            else:
                self.page_face_problem()
        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_skin_type_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 350, window=next_button)

        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_login, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 400, window=back_button)

    def page_face_problem(self):
        self.clear_window()

        # Ukuran window 1280x720
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg face problem fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # Menambahkan combobox untuk memilih masalah wajah
        face_problems = ["Normal", "Berjerawat"]
        combobox = ttk.Combobox(self.root, textvariable=self.selected_face_problem, values=face_problems, state="readonly", font=("Arial", 12))
        canvas.create_window(window_width // 2, 275, window=combobox)

        def handle_face_problem_selection():
            if not self.selected_face_problem.get():
                messagebox.showerror("Error", "Pilih masalah wajah terlebih dahulu!")
            else:
                self.page_treatments()

        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_face_problem_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 350, window=next_button)

        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_skin_type, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, 400, window=back_button)
   
    def page_treatments(self):
        self.clear_window()

        # Ukuran window 1280x720
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg perawatan wajah fix.png"  # Ganti dengan path gambar Anda
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height))  # Menyesuaikan gambar dengan ukuran window
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")
        
        # Mendapatkan perawatan yang direkomendasikan berdasarkan jenis kulit dan masalah wajah
        skin_type = self.selected_skin_type.get().lower()
        face_problem = self.selected_face_problem.get().lower()

        available_treatments = self.recommended_treatments.get((skin_type, face_problem), {})
        self.selected_treatments.clear()  # Menghindari data duplikat

        # Menambahkan perawatan yang tersedia ke dalam daftar
        y_position = 240  # Posisi awal untuk checkbutton
        for index, (treatment, price) in enumerate(available_treatments.items()):
            var = tk.BooleanVar()
            treatment_text = f"{treatment} - Rp {price:,}"
            checkbutton = tk.Checkbutton(
                self.root, text=treatment_text, variable=var, font=("Garamond", 12), fg="#000000", anchor="w", bg="#FFFFFF")
            canvas.create_window(window_width // 2, y_position + (index * 40), window=checkbutton)
            self.selected_treatments.append((treatment, var, price))

        # Fungsi untuk menangani validasi perawatan yang dipilih
        def handle_treatments_selection():
            # Validasi: Pastikan pengguna memilih perawatan terlebih dahulu
            if not any(t[1].get() for t in self.selected_treatments):
                messagebox.showerror("Error", "Pilih perawatan terlebih dahulu!")
            else:
                self.page_additional_treatments()  # Lanjut ke halaman perawatan tambahan

        # Tombol "Selanjutnya"
        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=handle_treatments_selection, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + len(self.selected_treatments) * 40 + 50, window=next_button)

        # Tombol "Kembali"
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_face_problem, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + len(self.selected_treatments) * 40 + 100, window=back_button)

    def page_additional_treatments(self):
        self.clear_window()
        
        window_width = 1280
        window_height = 720
        self.root.geometry(f"{window_width}x{window_height}")

        # Menambahkan gambar sebagai background
        bg_image_path = r"C:\Users\Latian\Documents\aplikasi-klinik-kecantikan\bg add treatment fix.png"
        bg_image = Image.open(bg_image_path)
        bg_image = bg_image.resize((window_width, window_height)) 
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Membuat canvas dan menambahkan gambar sebagai background
        canvas = tk.Canvas(self.root, width=window_width, height=window_height)
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")
        
        # Menampilkan Checkbutton untuk treatment tambahan
        y_position = 240  # Posisi awal di canvas
        for treatment, price in self.additional_treatments.items():
            var = tk.BooleanVar()
            treatment_text = f"{treatment} - Rp {price:,}"
            checkbutton = tk.Checkbutton(self.root, text=treatment_text, variable=var, font=("Garamond", 12), bg="#FFFFFF", fg="#000000", anchor="w")
            canvas.create_window(window_width // 2, y_position, window=checkbutton)
            y_position += 40  # Jarak antar checkbutton
            self.selected_additional_treatments.append((treatment, var, price))

        # Tombol "Selanjutnya"
        next_button = tk.Button(self.root, text="Selanjutnya", font=("Arial", 13), command=self.page_schedule, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + 50, window=next_button)

        # Tombol "Kembali"
        back_button = tk.Button(self.root, text="Kembali", font=("Arial", 13), command=self.page_treatments, bg="#990066", fg="#FFFFFF", width=10, height=1)
        canvas.create_window(window_width // 2, y_position + 100, window=back_button)
